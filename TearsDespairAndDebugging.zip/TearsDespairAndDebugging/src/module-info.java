/**
 * 
 */
/**
 * 
 */
module SP2025_CS3330_HW4_G0 {
	requires org.junit.jupiter.api;
	requires org.junit.jupiter.params;
}