package hw4.player;

import hw4.maze.Cell;
import hw4.maze.Row;
import hw4.maze.Grid;

public class Player {
	private Row row;
	private Cell cell;
	private Row currentRow;
	private Cell currentCell;
	
	public Player(Row currentRow, Cell currentCell) {
		this.currentRow = currentRow;
		this.currentCell = currentCell;
	}
	
	public Row getRow() {
		return this.row;
	}
	
	public Cell getCell() {
		return this.cell;
	}
	
	public void setCell(Cell cell, Grid grid) {
		this.cell = cell;
		
		for (Row r : grid.getRows()) {
	        if (r.getCells().contains(cell)) {
	            this.currentRow = r;  // This should set the currentRow correctly
	            break;
	        }
	    }
	    this.currentCell = cell;
	}
	
	public Row getCurrentRow() {
		return currentRow;
	}
	
	public Cell getCurrentCell() {
		return currentCell;
	}
	
	public Row getRowAbove(Grid grid) {
	    int rowIndex = grid.getRows().indexOf(this.row);
	    if (rowIndex > 0) {
	        return grid.getRows().get(rowIndex - 1);
	    }
	    return null;
	}

	public Row getRowBelow(Grid grid) {
	    int rowIndex = grid.getRows().indexOf(this.row);
	    if (rowIndex < grid.getRows().size() - 1) {
	        return grid.getRows().get(rowIndex + 1);
	    }
	    return null;
	}

	public int getColumnIndex() {
	    return row.getCells().indexOf(this.cell);
	}
	
	@Override
	public String toString() {
		return "Player [currentCell=" + currentCell + ", currentRow=" + currentRow + "]";
	}
}