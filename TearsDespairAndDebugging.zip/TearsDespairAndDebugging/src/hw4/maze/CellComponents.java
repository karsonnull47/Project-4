package hw4.maze;

public enum CellComponents {
	WALL,
	EXIT,
	APERTURE
}
