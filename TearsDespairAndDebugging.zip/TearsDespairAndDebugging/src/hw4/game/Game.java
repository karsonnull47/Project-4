package hw4.game;

import hw4.maze.Grid;

import java.util.ArrayList;
import java.util.Random;

import hw4.maze.Cell;
import hw4.maze.CellComponents;
import hw4.maze.Row;
import hw4.player.Player;

public class Game{
	private Grid grid;
	
	public Game(Grid grid) {
		this.grid = grid;
	}
	
	 public Game(int gridSize) {
	        if (gridSize < 3 || gridSize > 7) {
	            throw new IllegalArgumentException("Grid size is not valid");
	        } else {
	            this.grid = createRandomGrid(gridSize);
	        }
	    }

	    // Grid getter and setter.
	    public Grid getGrid() {
	        return grid;
	    }

	    public void setGrid(Grid grid) {
	        this.grid = grid;
	    }

	    // The actual playing of the game
	    public boolean play(Movement move, Player player) {
	    	if (move == null || player == null) {
	            return false;
	        }

	        int rowIndex = grid.getRows().indexOf(player.getCurrentRow());
	        int colIndex = player.getCurrentRow().getCells().indexOf(player.getCurrentCell());

	        //Each case facilitates the movement in any of the 4 directions.
	        switch (move) {
	            case UP:
	                if (rowIndex > 0) {
	                    Cell above = grid.getRows().get(rowIndex - 1).getCells().get(colIndex);
	                    if (player.getCurrentCell().getUp() == CellComponents.APERTURE && 
	                        above.getDown() == CellComponents.APERTURE) {
	                        player.setCell(above, grid);  
	                        return true;
	                    }
	                }
	                break;

	            case DOWN:
	                if (rowIndex < grid.getRows().size() - 1) {
	                    Cell below = grid.getRows().get(rowIndex + 1).getCells().get(colIndex);
	                    if (player.getCurrentCell().getDown() == CellComponents.APERTURE && 
	                        below.getUp() == CellComponents.APERTURE) {
	                        player.setCell(below, grid); 
	                        return true;
	                    }
	                }
	                break;

	            case LEFT:
	                if (colIndex > 0) {
	                    Cell left = player.getCurrentRow().getCells().get(colIndex - 1);
	                    if (player.getCurrentCell().getLeft() == CellComponents.APERTURE && 
	                        left.getRight() == CellComponents.APERTURE) {
	                        player.setCell(left, grid);  // Move the player
	                        return true;
	                    }
	                }
	                break;

	            case RIGHT:
	                if (colIndex < player.getCurrentRow().getCells().size() - 1) {
	                    Cell right = player.getCurrentRow().getCells().get(colIndex + 1);
	                    if (player.getCurrentCell().getRight() == CellComponents.APERTURE && 
	                        right.getLeft() == CellComponents.APERTURE) {
	                        player.setCell(right, grid);  // Move the player
	                        return true;
	                    }
	                }
	                break;
	                
	            default:
	                return false;
	        }
	        return false;
	  }

	   
	    public Grid createRandomGrid(int size) {
	        if (size < 3 || size > 5) return null;

	        ArrayList<Row> rows = new ArrayList<>();
	        Random rand = new Random();

	        for (int i = 0; i < size; i++) {
	            ArrayList<Cell> cells = new ArrayList<>();
	            for (int j = 0; j < size; j++) {
	                CellComponents left = (j == 0) ? CellComponents.WALL : CellComponents.APERTURE;
	                CellComponents right = (j == size - 1) ? CellComponents.WALL : CellComponents.APERTURE;
	                CellComponents up = (i == 0) ? CellComponents.WALL : CellComponents.APERTURE;
	                CellComponents down = (i == size - 1) ? CellComponents.WALL : CellComponents.APERTURE;

	                cells.add(new Cell(left, right, up, down));
	            }
	            rows.add(new Row(cells));
	        }

	        
	        int exitRowIndex = rand.nextInt(size);
	        Cell exitCell = rows.get(exitRowIndex).getCells().get(0);
	        exitCell.setLeft(CellComponents.EXIT);

	        return new Grid(rows);
	    }

	    @Override
	    public String toString() {
	        return "Game [grid=" + grid + "]";
	    }
}