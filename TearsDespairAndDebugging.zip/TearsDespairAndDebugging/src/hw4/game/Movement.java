package hw4.game;

public enum Movement {
	UP,
	DOWN,
	LEFT,
	RIGHT
}
